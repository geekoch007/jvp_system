<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Route;

Route::get('/', function () {return view('welcome');});
Route::get('/csrf', [AuthController::class, 'csrf']);

Route::any('/login', [AuthController::class, 'login']);

Route::middleware(['auth'])->group(function () {
    Route::resource('products', Products::class);
});


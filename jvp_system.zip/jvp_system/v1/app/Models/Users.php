<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Users extends Model
{
    protected $table = 'user';
    protected $primaryKey = 'uid';

    function gets($username) {
        $db = DB::table($this->table);
        $db->where('username', '=', $username);
        $result = $db->get();
        return $result;
    }
}

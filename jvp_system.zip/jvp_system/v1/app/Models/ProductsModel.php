<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ProductsModel extends Model
{
    use HasFactory;
    protected $table = 'products';
    protected $tbl_product_type = 'product_type';
    protected $tbl_user = 'user';

    public function gets() {
        $db = DB::table($this->table, 'p');
        $db->selectRaw('p.title, p.description, p.links, p.img, p.view, p.likes, p.un_likes, p.times, t.title as t2, u.username');
        $db->join(DB::Raw('(SELECT title, tid FROM '.$this->tbl_product_type.') as t'), 'p.tid', '=', 't.tid');
        $db->join(DB::Raw('(SELECT username, uid FROM '.$this->tbl_user.') as u'), 'p.uid', '=', 'u.uid');
        $db->where('p.is_delete', '=', 0);
        $result = $db->get();
        return $result;
    }

    public function getDetails($id) {
        $db = DB::table($this->table, 'p');
        $db->selectRaw('p.title, p.description, p.links, p.img, p.view, p.likes, p.un_likes, p.times, t.title as t2, u.username');
        $db->join(DB::Raw('(SELECT title, tid FROM '.$this->tbl_product_type.') as t'), 'p.tid', '=', 't.tid');
        $db->join(DB::Raw('(SELECT username, uid FROM '.$this->tbl_user.') as u'), 'p.uid', '=', 'u.uid');
        $db->where('p.is_delete', '=', 0);
        $db->where('p.pid', '=', trim($id));
        $result = $db->first();
        return $result;
    }
}

<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;

class Authenticate
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // if (!auth()->check()) {
        //     // User is not authenticated, redirect to the login page
        //     // return redirect()->route('login')->with('error', 'Please log in to access this page.');
        //     return response()->json([
        //         'message'=>'Please login first'
        //     ]);
        // }

        if ($request->header('token') && expireToken($request->header('token'))) {
            return response()->json([
                'status' => 'error',
                'message' => 'The token is expired.'
            ], 403);

        } else if(!$request->header('token')) {
            return response()->json([
                'status' => 'error',
                'message' => 'Unauthorized'
            ], 401);

        }

        // User is authenticated, allow the request to proceed
        return $next($request);
    }
}

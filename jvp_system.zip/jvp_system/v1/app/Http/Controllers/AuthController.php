<?php

namespace App\Http\Controllers;

use App\Models\Users;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AuthController extends Controller
{
    protected $userModel;
    /**
     * Create a new AuthController instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->userModel = new Users();
    }

    /**
     * Get a JWT via given credentials.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function login(Request $request)
    {
        $_data = array();
        $validated = array();
        $user = array();
        $inputs = $request->all();

        // check username //
        if($inputs['username']) {
            if(strlen(trim($inputs['username']))<2) $validated['username'] = 'The username requires a greater than 2 characters.';
            else if(strlen(trim($inputs['username']))>255) $validated['username'] = 'The username requires less than 255 characters.';
            else {
                $_data = $this->userModel->gets(trim($inputs['username']));
                if(!$_data || count($_data) <= 0) $validated['username'] = 'The username is not found. Please check your login again.';
            }
        } else $validated['username'] = 'The username is required.';

        // check password //
        if($inputs['password']) {
            if(strlen(trim($inputs['password']))<6) $validated['password'] = 'The password requires a greater than 6 characters.';
            else if($_data && count($_data) > 0) {
                foreach($_data as $key => $_val) {
                    if($_val->password != md5(trim($inputs['password']))) $validated['password'] = 'The password is incorrect. Please check your login again.';
                    else {
                        // clear validated //
                        $validated = array();
                        $user['username'] = $_val->username;
                        $user['sex'] = $_val->sex;
                        $user['contact'] = $_val->contact;
                        $user['permissions'] = $_val->permissions;

                        // update login //
                        $_user = $this->userModel::find($_val->uid);
                        $_user->last_login = date("Y-m-d h:i:s");
                        $_user->save();

                        break;
                    }
                }
            }
        } else $validated['password'] = 'The password is required.';

        // valid message //
        if($validated && (array_key_exists('username', $validated) || array_key_exists('password', $validated))) {
            return response()->json([
                'status' => 'error',
                'key' => (array_key_exists('username', $validated)) ? 'username' : 'password',
                'message' => (array_key_exists('username', $validated) ? $validated['username'] : $validated['password'])
            ], 302);
        }

        // $user['username'] = $inputs['username'];
        // $user['sex'] = 'f';
        // $user['contact'] = '090741315';
        // $user['permission'] = '1,2,3';
        // $user[''] = $_data;

        return response()->json([
            'data' => $user,
            'token' => createToken(user: $user)
        ], 200);
    }

    /**
     * Get the authenticated User.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function me()
    {
        //
    }

    /**
     * Log the user out (Invalidate the token).
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout()
    {
        //
    }

    /**
     * Refresh a token.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function refresh()
    {
        //
    }

    /**
     * Get the token array structure.
     *
     * @param  string $token
     *
     * @return \Illuminate\Http\JsonResponse
     */
    protected function respondWithToken($token)
    {
        //
    }

    public function csrf()
    {
        return response()->json(['csrf_token'=>csrf_token()]);
    }
}

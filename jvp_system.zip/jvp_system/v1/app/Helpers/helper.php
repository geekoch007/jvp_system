<?php

use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

/* ---- create token ---- */
function createToken($user=array()) {
    // create token //
    $user['expire_in'] = time() + ((int)env('TIMES') ? env('TIMES') : 60);
    $json = json_encode($user);
    $token = base64_encode($json);
    return $token;
}

/* ---- expire token ---- */
function expireToken($token=null) {
    // check token //
    $dec = base64_decode($token);
    $decJson = json_decode($dec);
    if(!isset($decJson->expire_in) || (isset($decJson->expire_in) && $decJson->expire_in <= time())) return true;
    return false;
}
